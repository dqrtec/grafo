arquivo = open("database_1.graph")

for linha in arquivo:
	if (linha == "0 1\n"):
		print(linha)
	if (linha == "1 0\n"):
		print(linha)
	if (linha == "0 1"):
		print(linha)
	if (linha == "1 0"):
		print(linha)