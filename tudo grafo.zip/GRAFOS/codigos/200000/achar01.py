arquivo = open("database_1.graph")

query = "0 1"

for linha in arquivo:
	if (linha == query+"\n"):
		print(linha)
