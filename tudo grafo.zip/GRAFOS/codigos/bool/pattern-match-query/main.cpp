#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <set>
#include <list>
#include <map>
#include <deque>
#include <chrono>
#include <climits>
#include "graph.h"
#include "bitmap.h"

using namespace std;

void matching(string caminhoQ, string caminhoG, int delta);
void Query(int interacaoI, Bitmap FI, int *ecentricidadeQ, string *Ordemlabls, int DELTA, int* caminhoVertices, Graph G, Graph Q);
void impirmirCaminhoVertices(Graph Q, int* caminhoVertices);

int main(int argc, char const *argv[]) {

    auto inicio = std::chrono::high_resolution_clock::now();

    std::string::size_type sz;
    int k = std::stoi (argv[3],&sz);
    matching(argv[1],argv[2], k );
    cout<<" -------!!!!!!!!---------"<< k <<endl;

    auto fim = std::chrono::high_resolution_clock::now() - inicio;
    long long milliseconds = std::chrono::duration_cast<std::chrono::milliseconds>(fim).count();
    cout<<"tempo gasto = "<< milliseconds<<" ms"<<endl;

    return 0;
}

void matching(string caminhoQ, string caminhoG, int delta) {

    int DELTA = delta;

    Graph Q(caminhoQ,true);
    Graph G(caminhoG,true);

    int* caminhoVertices = new int[Q.getN()];



    int* ecentricidadeQ = new int[Q.getN()];
    // Ordena as labels pela ecentricidade e coloca suas respectivas exentricidades no vertice ecentricidadeQ
    string* Ordemlabls = Q.ListaM(ecentricidadeQ);

    Vertex* vetorVerticesG = G.getV();
    for (int m1 = 0; m1 < G.getN(); m1++){
        if(vetorVerticesG[m1].getLabel() == Ordemlabls[0]){
            caminhoVertices[0] = m1;
            Bitmap F1 = G.bitmapDistanciaPermitida(m1,DELTA,ecentricidadeQ[0]) ;
            Query(2,F1,ecentricidadeQ,Ordemlabls, DELTA, caminhoVertices, G, Q);
        }
    }
}

void Query(int interacaoI, Bitmap FI, int *ecentricidadeQ, string *Ordemlabls, int DELTA, int* caminhoVertices, Graph G, Graph Q){
    for (int mi = 0; mi < G.getN(); mi++) {
        if ((FI.getPosition(mi)) && (G.getV()[mi].getLabel() == Ordemlabls[interacaoI - 1])) {
            caminhoVertices[interacaoI - 1] = mi;
            if (interacaoI == Q.getN()) {
                cout << "Query" << endl;
                //impirmirCaminhoVertices();
                //G.ImprimirVerticesQueCompoemCaminho(Q,caminhoVertices,DELTA,ecentricidadeQ);
            } else {
                Bitmap areaBuscaApartirMi = G.bitmapDistanciaPermitida(mi, DELTA, ecentricidadeQ[interacaoI - 1]);
                Bitmap proximaBitmapBusca = FI.intercecao(areaBuscaApartirMi);
                Query(interacaoI + 1, proximaBitmapBusca, ecentricidadeQ, Ordemlabls, DELTA, caminhoVertices, G, Q);
            }
        }
    }
}

void impirmirCaminhoVertices(Graph Q, int* caminhoVertices){
    cout << "Os vertices G que compoẽm a query são : ";
    for (int i = 0; i < Q.getN(); i++) {
        cout << caminhoVertices[i] << ", ";
    }
    cout << endl;
}