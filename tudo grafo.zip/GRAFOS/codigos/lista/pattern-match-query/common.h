//
// Created by Arida on 08/02/2019.
//

#ifndef PATTERNMATCHING_COMMON_H
#define PATTERNMATCHING_COMMON_H

class Vertex;
class Graph;
class GraphBitmap;
class Bitmap;

#endif //PATTERNMATCHING_COMMON_H
