#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <set>
#include <list>
#include <map>
#include <deque>
#include <chrono>
#include <climits>
#include "graph.h"
#include "bitmap.h"

using namespace std;

int DELTA = 5;

//Graph Q("/home/arida/Área de Trabalho/GRAFOS/codigos/20/database_1_1.query",true);// RandomizedDataBase/
//Graph G("/home/arida/Área de Trabalho/GRAFOS/codigos/20/database_1.graph",true);


//  Twitter
Graph Q("/media/arida/4d6879df-d0b5-44c1-bc1e-7dd2c1c6d4fd/daniel/twitter/twiter.query",true);
Graph G("/media/arida/4d6879df-d0b5-44c1-bc1e-7dd2c1c6d4fd/daniel/twitter/asdf.txt",true);

int* caminhoVertices = new int[Q.getN()];

void Query(int interacaoI,Bitmap FI,int* ecentricidadeQ, string* OrdemLabels);
void impirmirCaminhoVertices();

int main(int argc, char const *argv[]) {

    cout<<"------------------------!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!-----------------------"<<endl;

//    int a = 1030997;
//    cout<< "== "<< G.getV()[a].getLabel()<<"    "<< G.getAdjL()[a].size()  <<endl;
//
//    list<int>::iterator it;
//    for(it = G.getAdjL()[a].begin(); it != G.getAdjL()[a].end(); it++) {
//        cout<< "=visinho= "<< *it ;
//    }
//    cout<<""<<endl;

    auto inicio = std::chrono::high_resolution_clock::now();

    // Ordena as labels pela ecentricidade e coloca suas respectivas exentricidades no vertice ecentricidadeQ
    int* ecentricidadeQ = new int[Q.getN()];
    int* idVerticesOrdenados = Q.eccMais(ecentricidadeQ);
    string* Ordemlabls = Q.listaLabelsOrdemM(idVerticesOrdenados);

    Vertex* vetorVerticesG = G.getV();
    for (int m1 = 0; m1 < G.getN(); m1++){

        if(vetorVerticesG[m1].getLabel() == Ordemlabls[0]){
            caminhoVertices[0] = m1;
            Bitmap F1 = G.bitmapDistanciaPermitida(m1,DELTA,ecentricidadeQ[0]) ;
                cout<< m1 << "== "<< G.getV()[m1].getLabel()<<"    "<< G.getAdjL()[m1].size()  <<endl;

                list<int>::iterator it;
                for(it = G.getAdjL()[m1].begin(); it != G.getAdjL()[m1].end(); it++) {
                    cout<< "=visinho= "<< *it ;
                }
                cout<<""<<endl;
            Query(2,F1,ecentricidadeQ,Ordemlabls);
        }
    }

    auto fim = std::chrono::high_resolution_clock::now() - inicio;
    long long microseconds = std::chrono::duration_cast<std::chrono::microseconds>(fim).count();
    cout<<"\nTempo gasto = "<< microseconds<<endl;

    return 0;
}

void Query(int interacaoI, Bitmap FI, int* ecentricidadeQ,string* Ordemlabls){
    cout<<" vc esta na interacao "<< interacaoI <<endl;

    cout<<endl;
    FI.show();
    for (int mi = 0; mi < FI.getN(); mi++) {
        if( (G.getV()[ FI.getPosition(mi) ].getLabel() == Ordemlabls[interacaoI-1]) ){

            cout<< G.getV()[ FI.getPosition(mi) ].getLabel() <<endl;

            caminhoVertices[interacaoI-1] = G.getV()[ FI.getPosition(mi) ].getId() ;
            if(interacaoI == Q.getN()){
                cout<<"\nQuery"<<endl;
                impirmirCaminhoVertices();
                G.ImprimirVerticesQueCompoemCaminho(Q,caminhoVertices,DELTA,ecentricidadeQ);
            }else{
                Bitmap areaBuscaApartirMi = G.bitmapDistanciaPermitida(mi,DELTA,ecentricidadeQ[interacaoI-1]) ;
                Bitmap proximaBitmapBusca = FI.intercecao( areaBuscaApartirMi );
                cout<<"=>";
                areaBuscaApartirMi.show();
                proximaBitmapBusca.show();
                cout<<"<=";
                Query(interacaoI+1, proximaBitmapBusca ,ecentricidadeQ,Ordemlabls);
            }
        }
    }
}

void impirmirCaminhoVertices(){
    cout<<"Os vertices G que compoẽm a query são : ";
    for(int i=0; i< Q.getN(); i++ ){
        cout<<caminhoVertices[i] <<", ";
    }
    cout<<endl;
}